
import express from 'express'
import sql from 'mssql'
import { sqlConfig } from './database.js';
const pool = new sql.ConnectionPool(sqlConfig)
await pool.connect();

const router = express.Router()

router.get('/salas', async (req, res)=>{
    try {
        const {recordset} = await pool.query`select * from Glamur`
        return res.status(200).json(recordset)
    } catch (error) {
        return res.status(500).json('error...')
    }
})

export default router
